"""

"""


import phantom.rules as phantom
import json
from datetime import datetime, timedelta


@phantom.playbook_block()
def on_start(container):
    phantom.debug('on_start() called')

    # call 'if_closed_on_gti' block
    if_closed_on_gti(container=container)

    return

@phantom.playbook_block()
def if_closed_on_gti(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("if_closed_on_gti() called")

    tags_value = container.get("tags", None)

    if_closed_on_gti__if_closed_on_gti = None

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...
    if_closed_on_gti__if_closed_on_gti = False
    if isinstance(tags_value , list):
        if "closed_on_gti" in tags_value:
            if_closed_on_gti__if_closed_on_gti = True

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.save_block_result(key="if_closed_on_gti__inputs:0:container:tags", value=json.dumps(tags_value))

    phantom.save_block_result(key="if_closed_on_gti:if_closed_on_gti", value=json.dumps(if_closed_on_gti__if_closed_on_gti))

    phantom.save_block_result(key="if_closed_on_gti_called", value="True")

    decision_1(container=container)

    return


@phantom.playbook_block()
def decision_1(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("decision_1() called")

    # check for 'if' condition 1
    found_match_1 = phantom.decision(
        container=container,
        conditions=[
            ["if_closed_on_gti:custom_function:if_closed_on_gti", "==", False]
        ],
        conditions_dps=[
            ["if_closed_on_gti:custom_function:if_closed_on_gti", "==", False]
        ],
        name="decision_1:condition_1",
        scope="all",
        delimiter=None)

    # call connected blocks if condition 1 matched
    if found_match_1:
        get_alert_id(action=action, success=success, container=container, results=results, handle=handle)
        return

    return


@phantom.playbook_block()
def update_rs_alert_status_1(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("update_rs_alert_status_1() called")

    # phantom.debug('Action: {0} {1}'.format(action['name'], ('SUCCEEDED' if success else 'FAILED')))

    get_alert_id__alert_id = json.loads(_ if (_ := phantom.get_run_data(key="get_alert_id:alert_id")) != "" else "null")  # pylint: disable=used-before-assignment

    parameters = []

    if get_alert_id__alert_id is not None:
        parameters.append({
            "status": "Resolved",
            "alert_id": get_alert_id__alert_id,
        })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.act("update rs alert status", parameters=parameters, name="update_rs_alert_status_1", assets=["test2"])

    return


@phantom.playbook_block()
def get_alert_id(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("get_alert_id() called")

    container_artifact_data = phantom.collect2(container=container, datapath=["artifact:*.cef.alert_id"])

    container_artifact_cef_item_0 = [item[0] for item in container_artifact_data]

    get_alert_id__alert_id = None

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...
    if isinstance(container_artifact_cef_item_0, list):
        if len(container_artifact_cef_item_0)>0:
                    if container_artifact_cef_item_0[0]:
                        get_alert_id__alert_id = container_artifact_cef_item_0[0]
    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.save_block_result(key="get_alert_id__inputs:0:artifact:*.cef.alert_id", value=json.dumps(container_artifact_cef_item_0))

    phantom.save_block_result(key="get_alert_id:alert_id", value=json.dumps(get_alert_id__alert_id))

    phantom.save_block_result(key="get_alert_id_called", value="True")

    update_rs_alert_status_1(container=container)

    return


@phantom.playbook_block()
def on_finish(container, summary):
    phantom.debug("on_finish() called")

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    return