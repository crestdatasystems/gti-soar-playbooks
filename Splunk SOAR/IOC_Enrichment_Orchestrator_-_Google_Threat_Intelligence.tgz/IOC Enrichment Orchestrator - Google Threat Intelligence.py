"""
This automation playbook extracts IOC values from incoming artifacts and orchestrates enrichment by invoking the GTI Enrich IOC input playbook.
"""


import phantom.rules as phantom
import json
from datetime import datetime, timedelta


@phantom.playbook_block()
def on_start(container):
    phantom.debug('on_start() called')

    # call 'extract_iocs' block
    extract_iocs(container=container)

    return

@phantom.playbook_block()
def extract_iocs(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("extract_iocs() called")

    ################################################################################
    # Extracts IOC values from the artifact fields provided to the playbook.
    ################################################################################

    container_artifact_data = phantom.collect2(container=container, datapath=["artifact:*.cef.sourceAddress","artifact:*.cef.requestURL"])

    container_artifact_cef_item_0 = [item[0] for item in container_artifact_data]
    container_artifact_cef_item_1 = [item[1] for item in container_artifact_data]

    extract_iocs__iocs = None

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...
    def flatten_list(data):
        """Flatten the list of data items"""
        result = []
        for item in data:
	        if isinstance(item, list):
	            result.extend(flatten_list(item))
	        else:
	            result.append(item)
        return result
    
    extract_iocs__iocs = flatten_list(container_artifact_data)
    phantom.debug(f"extract_iocs__iocs : {extract_iocs__iocs}")


    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.save_block_result(key="extract_iocs__inputs:0:artifact:*.cef.sourceAddress", value=json.dumps(container_artifact_cef_item_0))
    phantom.save_block_result(key="extract_iocs__inputs:1:artifact:*.cef.requestURL", value=json.dumps(container_artifact_cef_item_1))

    phantom.save_block_result(key="extract_iocs:iocs", value=json.dumps(extract_iocs__iocs))

    playbook_gti___enrich_ioc_1(container=container)

    return


@phantom.playbook_block()
def playbook_gti___enrich_ioc_1(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("playbook_gti___enrich_ioc_1() called")

    extract_iocs__iocs = json.loads(_ if (_ := phantom.get_run_data(key="extract_iocs:iocs")) != "" else "null")  # pylint: disable=used-before-assignment

    inputs = {
        "ioc": extract_iocs__iocs,
    }

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...
    for ioc in inputs['ioc']:
        input_dict = {'ioc': ioc}
        playbook_run_id = phantom.playbook("local/IOC Enrichment and Blocking - Google Threat Intelligence", container=container, inputs=input_dict)
        phantom.debug(f"playbook_run_id : {playbook_run_id}")
        
        

    ################################################################################
    ## Custom Code End
    ################################################################################

    # call playbook "local/GTI - Enrich IOC", returns the playbook_run_id
    #playbook_run_id = phantom.playbook("local/GTI - Enrich IOC", container=container, inputs=inputs)

    return

@phantom.playbook_block()
def on_finish(container, summary):
    phantom.debug("on_finish() called")

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    return