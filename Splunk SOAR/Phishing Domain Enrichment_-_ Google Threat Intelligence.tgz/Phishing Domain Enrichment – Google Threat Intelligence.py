"""
This input playbook enriches a phishing-related domain using Google Threat Intelligence and applies response actions when the domain is malicious.
"""


import phantom.rules as phantom
import json
from datetime import datetime, timedelta


@phantom.playbook_block()
def on_start(container):
    phantom.debug('on_start() called')

    # call 'get_domain_report' block
    get_domain_report(container=container)

    return

@phantom.playbook_block()
def get_domain_report(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("get_domain_report() called")

    # phantom.debug('Action: {0} {1}'.format(action['name'], ('SUCCEEDED' if success else 'FAILED')))

    ################################################################################
    # Retrieves threat intelligence details for the domain using GTI Get IOC Report.
    ################################################################################

    playbook_input_domain = phantom.collect2(container=container, datapath=["playbook_input:domain"])

    parameters = []

    # build parameters list for 'get_domain_report' call
    for playbook_input_domain_item in playbook_input_domain:
        if playbook_input_domain_item[0] is not None:
            parameters.append({
                "entity": playbook_input_domain_item[0],
            })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.act("get ioc report", parameters=parameters, name="get_domain_report", assets=["test-gti"], callback=parse_gti_enrichment_output)

    return


@phantom.playbook_block()
def parse_gti_enrichment_output(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("parse_gti_enrichment_output() called")

    ################################################################################
    # Extracts relevant fields from the GTI response for decision-making and reporting.
    ################################################################################

    get_domain_report_result_data = phantom.collect2(container=container, datapath=["get_domain_report:action_result.data.*.data"], action_results=results)

    get_domain_report_result_item_0 = [item[0] for item in get_domain_report_result_data]

    parse_gti_enrichment_output__ioc_value = None
    parse_gti_enrichment_output__threat_score = None
    parse_gti_enrichment_output__verdict = None
    parse_gti_enrichment_output__confidence = None
    parse_gti_enrichment_output__severity = None
    parse_gti_enrichment_output__categories = None
    parse_gti_enrichment_output__malware_families = None
    parse_gti_enrichment_output__raw_attributes = None
    parse_gti_enrichment_output__artifact_data = None
    parse_gti_enrichment_output__ioc_type = None

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...
     
    def normalize_soar_severity(value):
        """
        Map GTI severity with severity of Splunk SOAR 
        """
        if not value:
            return ""
    
        value = str(value).strip().upper()
    
        mapping = {
            "SEVERITY_HIGH": "high",
            "SEVERITY_MEDIUM": "medium",
            "SEVERITY_LOW": "low",
        }
    
        return mapping.get(value, "")
    
    
    def get_path(dct, path, default=None):
        cur = dct
        for key in path:
            if not isinstance(cur, dict):
                return default
            cur = cur.get(key)
            if cur is None:
                return default
        return cur
    
    
    ioc_type = get_domain_report_result_item_0[0]["type"]
    ioc_id = get_domain_report_result_item_0[0]["id"]
    item = get_domain_report_result_item_0[0]["attributes"]

    parse_gti_enrichment_output__ioc_value = ioc_id
    parse_gti_enrichment_output__threat_score = get_path(
        item, ["gti_assessment", "threat_score", "value"], 0
    )
    parse_gti_enrichment_output__verdict = get_path(
        item, ["gti_assessment", "verdict", "value"], "VERDICT_UNKNOWN"
    )
    parse_gti_enrichment_output__confidence = get_path(
        item, ["gti_assessment", "contributing_factors", "gti_confidence_score"], 0
    )
    parse_gti_enrichment_output__severity = normalize_soar_severity(get_path(
        item, ["gti_assessment", "severity", "value"], ""
    ))
    parse_gti_enrichment_output__categories = get_path(
        item, ["gti_assessment", "contributing_factors", "normalised_categories"], []
    )
    parse_gti_enrichment_output__malware_families = get_path(
        item,
        ["gti_assessment", "contributing_factors", "mandiant_association_malware"],
        False,
    )
    parse_gti_enrichment_output__first_seen = item.get("first_seen_itw_date")
    parse_gti_enrichment_output__last_seen = item.get("last_seen_itw_date")
    
    # STRICT pass-through: identical to file content
    parse_gti_enrichment_output__raw_attributes = item.get("gti_assessment", {})
    parse_gti_enrichment_output__artifact_data = {
        "cef": {
            f"gti_{ioc_type}_value": parse_gti_enrichment_output__ioc_value,
            f"gti_{ioc_type}_threat_score": parse_gti_enrichment_output__threat_score,
            f"gti_{ioc_type}_verdict": parse_gti_enrichment_output__verdict,
            f"gti_{ioc_type}_confidence": parse_gti_enrichment_output__confidence,
            f"gti_{ioc_type}_severity": parse_gti_enrichment_output__severity,
        }
    }
    parse_gti_enrichment_output__ioc_type = ioc_type

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.save_block_result(key="parse_gti_enrichment_output__inputs:0:get_domain_report:action_result.data.*.data", value=json.dumps(get_domain_report_result_item_0))

    phantom.save_block_result(key="parse_gti_enrichment_output:ioc_value", value=json.dumps(parse_gti_enrichment_output__ioc_value))
    phantom.save_block_result(key="parse_gti_enrichment_output:threat_score", value=json.dumps(parse_gti_enrichment_output__threat_score))
    phantom.save_block_result(key="parse_gti_enrichment_output:verdict", value=json.dumps(parse_gti_enrichment_output__verdict))
    phantom.save_block_result(key="parse_gti_enrichment_output:confidence", value=json.dumps(parse_gti_enrichment_output__confidence))
    phantom.save_block_result(key="parse_gti_enrichment_output:severity", value=json.dumps(parse_gti_enrichment_output__severity))
    phantom.save_block_result(key="parse_gti_enrichment_output:categories", value=json.dumps(parse_gti_enrichment_output__categories))
    phantom.save_block_result(key="parse_gti_enrichment_output:malware_families", value=json.dumps(parse_gti_enrichment_output__malware_families))
    phantom.save_block_result(key="parse_gti_enrichment_output:raw_attributes", value=json.dumps(parse_gti_enrichment_output__raw_attributes))
    phantom.save_block_result(key="parse_gti_enrichment_output:artifact_data", value=json.dumps(parse_gti_enrichment_output__artifact_data))
    phantom.save_block_result(key="parse_gti_enrichment_output:ioc_type", value=json.dumps(parse_gti_enrichment_output__ioc_type))

    update_artifact(container=container)

    return


@phantom.playbook_block()
def update_artifact(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("update_artifact() called")

    ################################################################################
    # Updates the artifact fields such as severity and enrichment context.
    ################################################################################

    container_artifact_data = phantom.collect2(container=container, datapath=["artifact:*.id","artifact:*.id"])
    parse_gti_enrichment_output__severity = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:severity")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_gti_enrichment_output__artifact_data = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:artifact_data")) != "" else "null")  # pylint: disable=used-before-assignment

    parameters = []

    # build parameters list for 'update_artifact' call
    for container_artifact_item in container_artifact_data:
        parameters.append({
            "name": None,
            "tags": None,
            "label": None,
            "severity": parse_gti_enrichment_output__severity,
            "cef_field": None,
            "cef_value": None,
            "input_json": parse_gti_enrichment_output__artifact_data,
            "artifact_id": container_artifact_item[0],
            "cef_data_type": None,
            "overwrite_tags": None,
        })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.custom_function(custom_function="community/artifact_update", parameters=parameters, name="update_artifact", callback=check_malicious_domain)

    return


@phantom.playbook_block()
def check_malicious_domain(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("check_malicious_domain() called")

    ################################################################################
    # Evaluates whether the Domain is malicious based on verdict and threat score.
    ################################################################################

    # check for 'if' condition 1
    found_match_1 = phantom.decision(
        container=container,
        logical_operator="or",
        conditions=[
            ["parse_gti_enrichment_output:custom_function:threat_score", ">=", 90],
            ["parse_gti_enrichment_output:custom_function:severity", "==", "high"],
            ["parse_gti_enrichment_output:custom_function:verdict", "==", "VERDICT_MALICIOUS"]
        ],
        conditions_dps=[
            ["parse_gti_enrichment_output:custom_function:threat_score", ">=", 90],
            ["parse_gti_enrichment_output:custom_function:severity", "==", "high"],
            ["parse_gti_enrichment_output:custom_function:verdict", "==", "VERDICT_MALICIOUS"]
        ],
        name="check_malicious_domain:condition_1",
        delimiter=None)

    # call connected blocks if condition 1 matched
    if found_match_1:
        create_malicious_domain_note(action=action, success=success, container=container, results=results, handle=handle)
        return

    return


@phantom.playbook_block()
def add_artifact_note(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("add_artifact_note() called")

    ################################################################################
    # Adds the prepared malicious IOC note to the artifact
    ################################################################################

    create_malicious_domain_note__artifact_note = json.loads(_ if (_ := phantom.get_run_data(key="create_malicious_domain_note:artifact_note")) != "" else "null")  # pylint: disable=used-before-assignment

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.add_note(container=container, content=create_malicious_domain_note__artifact_note, note_format="html", note_type="general", title="GTI Domain Enrichment Summary")

    return


@phantom.playbook_block()
def create_malicious_domain_note(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("create_malicious_domain_note() called")

    ################################################################################
    # Prepares a detailed artifact note summarizing malicious Domain intelligence.
    ################################################################################

    playbook_input_email = phantom.collect2(container=container, datapath=["playbook_input:email"])
    parse_gti_enrichment_output__ioc_value = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:ioc_value")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_gti_enrichment_output__raw_attributes = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:raw_attributes")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_gti_enrichment_output__threat_score = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:threat_score")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_gti_enrichment_output__verdict = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:verdict")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_gti_enrichment_output__confidence = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:confidence")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_gti_enrichment_output__severity = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:severity")) != "" else "null")  # pylint: disable=used-before-assignment
    parse_gti_enrichment_output__ioc_type = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment_output:ioc_type")) != "" else "null")  # pylint: disable=used-before-assignment

    playbook_input_email_values = [item[0] for item in playbook_input_email]

    create_malicious_domain_note__artifact_note = None

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...
    block_note = "As the Domain is malicious, email should be blocked."
    create_malicious_domain_note__artifact_note = (
        f"Email: {playbook_input_email_values[0]}\n"
        f"Domain : {parse_gti_enrichment_output__ioc_value}\n"
        f"Threat_score : {parse_gti_enrichment_output__threat_score}\n"
        f"verdict : {parse_gti_enrichment_output__verdict}\n"
        f"Confidence : {parse_gti_enrichment_output__confidence}\n"
        f"{block_note}"
    )
    phantom.debug(f"createed artifact_note : {create_malicious_domain_note__artifact_note}")


    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.save_block_result(key="create_malicious_domain_note__inputs:0:parse_gti_enrichment_output:custom_function:ioc_value", value=json.dumps(parse_gti_enrichment_output__ioc_value))
    phantom.save_block_result(key="create_malicious_domain_note__inputs:1:parse_gti_enrichment_output:custom_function:raw_attributes", value=json.dumps(parse_gti_enrichment_output__raw_attributes))
    phantom.save_block_result(key="create_malicious_domain_note__inputs:2:parse_gti_enrichment_output:custom_function:threat_score", value=json.dumps(parse_gti_enrichment_output__threat_score))
    phantom.save_block_result(key="create_malicious_domain_note__inputs:3:parse_gti_enrichment_output:custom_function:verdict", value=json.dumps(parse_gti_enrichment_output__verdict))
    phantom.save_block_result(key="create_malicious_domain_note__inputs:4:parse_gti_enrichment_output:custom_function:confidence", value=json.dumps(parse_gti_enrichment_output__confidence))
    phantom.save_block_result(key="create_malicious_domain_note__inputs:5:parse_gti_enrichment_output:custom_function:severity", value=json.dumps(parse_gti_enrichment_output__severity))
    phantom.save_block_result(key="create_malicious_domain_note__inputs:6:parse_gti_enrichment_output:custom_function:ioc_type", value=json.dumps(parse_gti_enrichment_output__ioc_type))
    phantom.save_block_result(key="create_malicious_domain_note__inputs:7:playbook_input:email", value=json.dumps(playbook_input_email_values))

    phantom.save_block_result(key="create_malicious_domain_note:artifact_note", value=json.dumps(create_malicious_domain_note__artifact_note))

    add_artifact_note(container=container)

    return


@phantom.playbook_block()
def on_finish(container, summary):
    phantom.debug("on_finish() called")

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    return