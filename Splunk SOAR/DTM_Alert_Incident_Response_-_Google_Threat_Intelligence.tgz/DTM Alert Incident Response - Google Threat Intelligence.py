"""
This playbook evaluates the severity of Google Threat Intelligence DTM alerts and automatically escalates high-severity events by creating a ServiceNow incident.
"""


import phantom.rules as phantom
import json
from datetime import datetime, timedelta


@phantom.playbook_block()
def on_start(container):
    phantom.debug('on_start() called')

    # call 'check_event_severity' block
    check_event_severity(container=container)

    return

@phantom.playbook_block()
def check_event_severity(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("check_event_severity() called")

    ################################################################################
    # Determines whether the DTM alert severity meets the high-risk threshold.
    ################################################################################

    # collect filtered artifact ids and results for 'if' condition 1
    matched_artifacts_1, matched_results_1 = phantom.condition(
        container=container,
        conditions=[
            ["artifact:*.severity", "==", "high"]
        ],
        conditions_dps=[
            ["artifact:*.severity", "==", "high"]
        ],
        name="check_event_severity:condition_1",
        delimiter=None)

    # call connected blocks if filtered artifacts or results
    if matched_artifacts_1 or matched_results_1:
        prepare_snow_ticket(action=action, success=success, container=container, results=results, handle=handle, filtered_artifacts=matched_artifacts_1, filtered_results=matched_results_1)

    return


@phantom.playbook_block()
def prepare_snow_ticket(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("prepare_snow_ticket() called")

    ################################################################################
    # Prepares a concise ServiceNow ticket description using DTM alert context.
    ################################################################################

    container_artifact_data = phantom.collect2(container=container, datapath=["artifact:*.cef.Tags","artifact:*.cef.Alert ID","artifact:*.cef.Alert Type","artifact:*.cef.Confidence","artifact:*.cef.Monitor ID","artifact:*.cef.Alert Title","artifact:*.cef.Alert Status","artifact:*.cef.Alert Summary","artifact:*.cef.AI Doc Summary"])

    container_artifact_cef_item_0 = [item[0] for item in container_artifact_data]
    container_artifact_cef_item_1 = [item[1] for item in container_artifact_data]
    container_artifact_cef_item_2 = [item[2] for item in container_artifact_data]
    container_artifact_cef_item_3 = [item[3] for item in container_artifact_data]
    container_artifact_cef_item_4 = [item[4] for item in container_artifact_data]
    container_artifact_cef_item_5 = [item[5] for item in container_artifact_data]
    container_artifact_cef_item_6 = [item[6] for item in container_artifact_data]
    container_artifact_cef_item_7 = [item[7] for item in container_artifact_data]
    container_artifact_cef_item_8 = [item[8] for item in container_artifact_data]

    prepare_snow_ticket__description = None
    prepare_snow_ticket__short_description = None

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...
        # Defensive defaults
    tags = container_artifact_cef_item_0[0]
    alert_id = container_artifact_cef_item_1[0] or "N/A"
    alert_type = container_artifact_cef_item_2[0] or "Unknown"
    confidence = container_artifact_cef_item_3[0] or "N/A"
    monitor_id = container_artifact_cef_item_4[0] or "N/A"
    alert_title = container_artifact_cef_item_5[0] or "GTI DTM Alert"
    alert_status = container_artifact_cef_item_6[0] or "Unknown"
    alert_summary = container_artifact_cef_item_7[0] or "No summary available"
    alert_ai_summary =  container_artifact_cef_item_8[0] or "No AI summary available"
      
    prepare_snow_ticket__short_description = ( f"[GTI DTM] {alert_title}")
    
    # Description
    prepare_snow_ticket__description = (
        "A high-severity Google Threat Intelligence DTM alert has been generated.\n\n"
        "Alert Details:\n"
        f"- Alert ID: {alert_id}\n"
        f"- Alert Type: {alert_type}\n"
        f"- Alert Title: {alert_title}\n"
        f"- Alert Status: {alert_status}\n"
        f"- Confidence Score: {confidence}\n"
        f"- Tags: {(tags)}\n\n"
        "Monitoring Information:\n"
        f"- Monitor ID: {monitor_id}\n\n"
        "Summary\n"
        f"- Normal Summary : {alert_summary}\n"
        f"- AI Summary : {alert_ai_summary}\n\n"
        "This ticket was automatically created by Splunk SOAR based on a GTI DTM alert."
    )
    
    phantom.debug(f"ServiceNow ticket short desc : {prepare_snow_ticket__short_description}")
    phantom.debug(f"ServiceNow ticket desc : {prepare_snow_ticket__description}")

    

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.save_block_result(key="prepare_snow_ticket__inputs:0:artifact:*.cef.Tags", value=json.dumps(container_artifact_cef_item_0))
    phantom.save_block_result(key="prepare_snow_ticket__inputs:1:artifact:*.cef.Alert ID", value=json.dumps(container_artifact_cef_item_1))
    phantom.save_block_result(key="prepare_snow_ticket__inputs:2:artifact:*.cef.Alert Type", value=json.dumps(container_artifact_cef_item_2))
    phantom.save_block_result(key="prepare_snow_ticket__inputs:3:artifact:*.cef.Confidence", value=json.dumps(container_artifact_cef_item_3))
    phantom.save_block_result(key="prepare_snow_ticket__inputs:4:artifact:*.cef.Monitor ID", value=json.dumps(container_artifact_cef_item_4))
    phantom.save_block_result(key="prepare_snow_ticket__inputs:5:artifact:*.cef.Alert Title", value=json.dumps(container_artifact_cef_item_5))
    phantom.save_block_result(key="prepare_snow_ticket__inputs:6:artifact:*.cef.Alert Status", value=json.dumps(container_artifact_cef_item_6))
    phantom.save_block_result(key="prepare_snow_ticket__inputs:7:artifact:*.cef.Alert Summary", value=json.dumps(container_artifact_cef_item_7))
    phantom.save_block_result(key="prepare_snow_ticket__inputs:8:artifact:*.cef.AI Doc Summary", value=json.dumps(container_artifact_cef_item_8))

    phantom.save_block_result(key="prepare_snow_ticket:description", value=json.dumps(prepare_snow_ticket__description))
    phantom.save_block_result(key="prepare_snow_ticket:short_description", value=json.dumps(prepare_snow_ticket__short_description))

    create_snow_ticket(container=container)

    return


@phantom.playbook_block()
def create_snow_ticket(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("create_snow_ticket() called")

    # phantom.debug('Action: {0} {1}'.format(action['name'], ('SUCCEEDED' if success else 'FAILED')))

    ################################################################################
    # Creates a ServiceNow incident for the high-severity DTM alert.
    ################################################################################

    prepare_snow_ticket__description = json.loads(_ if (_ := phantom.get_run_data(key="prepare_snow_ticket:description")) != "" else "null")  # pylint: disable=used-before-assignment
    prepare_snow_ticket__short_description = json.loads(_ if (_ := phantom.get_run_data(key="prepare_snow_ticket:short_description")) != "" else "null")  # pylint: disable=used-before-assignment

    parameters = []

    parameters.append({
        "table": "incident",
        "description": prepare_snow_ticket__description,
        "short_description": prepare_snow_ticket__short_description,
    })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.act("create ticket", parameters=parameters, name="create_snow_ticket", assets=["test_snow"])

    return


@phantom.playbook_block()
def on_finish(container, summary):
    phantom.debug("on_finish() called")

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    return