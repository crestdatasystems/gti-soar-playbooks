"""
This playbook evaluates the severity of Google Threat Intelligence ASM alerts and automatically escalates high-severity events by creating a ServiceNow incident.
"""


import phantom.rules as phantom
import json
from datetime import datetime, timedelta


@phantom.playbook_block()
def on_start(container):
    phantom.debug('on_start() called')

    # call 'check_event_severity' block
    check_event_severity(container=container)

    return

@phantom.playbook_block()
def check_event_severity(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("check_event_severity() called")

    ################################################################################
    # Determines whether the ASM alert severity meets the high-risk threshold.
    ################################################################################

    # collect filtered artifact ids and results for 'if' condition 1
    matched_artifacts_1, matched_results_1 = phantom.condition(
        container=container,
        conditions=[
            ["artifact:*.cef.Severity (GTI)", ">=", 4]
        ],
        conditions_dps=[
            ["artifact:*.cef.Severity (GTI)", ">=", 4]
        ],
        name="check_event_severity:condition_1",
        delimiter=None)

    # call connected blocks if filtered artifacts or results
    if matched_artifacts_1 or matched_results_1:
        prepare_snow_ticket(action=action, success=success, container=container, results=results, handle=handle, filtered_artifacts=matched_artifacts_1, filtered_results=matched_results_1)

    return


@phantom.playbook_block()
def prepare_snow_ticket(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("prepare_snow_ticket() called")

    ################################################################################
    # Prepares a concise ServiceNow ticket description using ASM alert context.
    ################################################################################

    container_artifact_data = phantom.collect2(container=container, datapath=["artifact:*.cef.Tags","artifact:*.cef.Summary.pretty_name","artifact:*.cef.Status","artifact:*.cef.Category","artifact:*.cef.Confidence","artifact:*.cef.Issue ID","artifact:*.cef.Collection","artifact:*.cef.Description","artifact:*.cef.Entity Type","artifact:*.cef.Severity (GTI)","artifact:*.cef.Affected Entity"])

    container_artifact_cef_item_0 = [item[0] for item in container_artifact_data]
    container_artifact_cef_item_1 = [item[1] for item in container_artifact_data]
    container_artifact_cef_item_2 = [item[2] for item in container_artifact_data]
    container_artifact_cef_item_3 = [item[3] for item in container_artifact_data]
    container_artifact_cef_item_4 = [item[4] for item in container_artifact_data]
    container_artifact_cef_item_5 = [item[5] for item in container_artifact_data]
    container_artifact_cef_item_6 = [item[6] for item in container_artifact_data]
    container_artifact_cef_item_7 = [item[7] for item in container_artifact_data]
    container_artifact_cef_item_8 = [item[8] for item in container_artifact_data]
    container_artifact_cef_item_9 = [item[9] for item in container_artifact_data]
    container_artifact_cef_item_10 = [item[10] for item in container_artifact_data]

    prepare_snow_ticket__description = None
    prepare_snow_ticket__short_description = None

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...
    """
    Prepare ServiceNow ticket fields for a GTI ASM alert.
    Outputs:
    - prepare_snow_ticket__short_description
    - prepare_snow_ticket__description
    """
    
    
    # Defensive defaults
    tags = container_artifact_cef_item_0[0]
    summary_pretty_name = container_artifact_cef_item_1[0] or "GTI ASM Alert"
    status = container_artifact_cef_item_2[0] or "Unknown"
    category = container_artifact_cef_item_3[0] or "Uncategorized"
    confidence = container_artifact_cef_item_4[0] or "Uncategorized"
    issue_id = container_artifact_cef_item_5[0] or "N/A"
    collection = container_artifact_cef_item_6[0] or "N/A"
    description = container_artifact_cef_item_7[0] or "No description available"
    entity_type = container_artifact_cef_item_8[0] or "Unknown"
    severity = container_artifact_cef_item_9[0] or "Uncategorized"
    affected_entity = container_artifact_cef_item_10[0] or "Unknown"
    

    # Short Description
    prepare_snow_ticket__short_description = (
        f"[GTI ASM] {summary_pretty_name} – {affected_entity}"
    )
    
    # Description
    prepare_snow_ticket__description = (
        "A high-severity Google Threat Intelligence ASM alert has been detected.\n\n"
        "Alert Overview:\n"
        f"- Issue ID: {issue_id}\n"
        f"- Summary: {summary_pretty_name}\n"
        f"- Status: {status}\n"
        f"- Category: {category}\n"
        f"- Severity (GTI): {severity}\n"
        f"- Confidence Score: {confidence}\n\n"
        "Affected Entity:\n"
        f"- Entity Type: {entity_type}\n"
        f"- Entity: {affected_entity}\n\n"
        "Collection Details:\n"
        f"- Collection: {collection}\n"
        f"- Tags: {tags}\n\n"
        "Description:\n"
        f"{description}\n\n"
     
        "This incident was automatically created by Splunk SOAR based on a GTI ASM alert."
    )
    

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.save_block_result(key="prepare_snow_ticket__inputs:0:artifact:*.cef.Tags", value=json.dumps(container_artifact_cef_item_0))
    phantom.save_block_result(key="prepare_snow_ticket__inputs:1:artifact:*.cef.Summary.pretty_name", value=json.dumps(container_artifact_cef_item_1))
    phantom.save_block_result(key="prepare_snow_ticket__inputs:2:artifact:*.cef.Status", value=json.dumps(container_artifact_cef_item_2))
    phantom.save_block_result(key="prepare_snow_ticket__inputs:3:artifact:*.cef.Category", value=json.dumps(container_artifact_cef_item_3))
    phantom.save_block_result(key="prepare_snow_ticket__inputs:4:artifact:*.cef.Confidence", value=json.dumps(container_artifact_cef_item_4))
    phantom.save_block_result(key="prepare_snow_ticket__inputs:5:artifact:*.cef.Issue ID", value=json.dumps(container_artifact_cef_item_5))
    phantom.save_block_result(key="prepare_snow_ticket__inputs:6:artifact:*.cef.Collection", value=json.dumps(container_artifact_cef_item_6))
    phantom.save_block_result(key="prepare_snow_ticket__inputs:7:artifact:*.cef.Description", value=json.dumps(container_artifact_cef_item_7))
    phantom.save_block_result(key="prepare_snow_ticket__inputs:8:artifact:*.cef.Entity Type", value=json.dumps(container_artifact_cef_item_8))
    phantom.save_block_result(key="prepare_snow_ticket__inputs:9:artifact:*.cef.Severity (GTI)", value=json.dumps(container_artifact_cef_item_9))
    phantom.save_block_result(key="prepare_snow_ticket__inputs:10:artifact:*.cef.Affected Entity", value=json.dumps(container_artifact_cef_item_10))

    phantom.save_block_result(key="prepare_snow_ticket:description", value=json.dumps(prepare_snow_ticket__description))
    phantom.save_block_result(key="prepare_snow_ticket:short_description", value=json.dumps(prepare_snow_ticket__short_description))

    create_snow_ticket(container=container)

    return


@phantom.playbook_block()
def create_snow_ticket(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("create_snow_ticket() called")

    # phantom.debug('Action: {0} {1}'.format(action['name'], ('SUCCEEDED' if success else 'FAILED')))

    ################################################################################
    # Creates a ServiceNow incident for the high-severity ASM alert.
    ################################################################################

    prepare_snow_ticket__description = json.loads(_ if (_ := phantom.get_run_data(key="prepare_snow_ticket:description")) != "" else "null")  # pylint: disable=used-before-assignment
    prepare_snow_ticket__short_description = json.loads(_ if (_ := phantom.get_run_data(key="prepare_snow_ticket:short_description")) != "" else "null")  # pylint: disable=used-before-assignment

    parameters = []

    parameters.append({
        "table": "incident",
        "description": prepare_snow_ticket__description,
        "short_description": prepare_snow_ticket__short_description,
    })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.act("create ticket", parameters=parameters, name="create_snow_ticket", assets=["test_snow"])

    return


@phantom.playbook_block()
def on_finish(container, summary):
    phantom.debug("on_finish() called")

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    return