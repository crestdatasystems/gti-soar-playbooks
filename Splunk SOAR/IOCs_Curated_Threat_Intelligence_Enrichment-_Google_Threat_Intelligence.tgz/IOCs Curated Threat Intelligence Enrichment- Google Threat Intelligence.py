"""
This playbook enriches IOCs using Google Threat Intelligence curated associations to provide analyst-verified threat context and relationships.
"""


import phantom.rules as phantom
import json
from datetime import datetime, timedelta


@phantom.playbook_block()
def on_start(container):
    phantom.debug('on_start() called')

    # call 'get_curated_associations' block
    get_curated_associations(container=container)

    return

@phantom.playbook_block()
def get_curated_associations(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("get_curated_associations() called")

    # phantom.debug('Action: {0} {1}'.format(action['name'], ('SUCCEEDED' if success else 'FAILED')))

    ################################################################################
    # Retrieves curated threat associations for the IOC from Google Threat Intelligence.
    ################################################################################

    container_artifact_data = phantom.collect2(container=container, datapath=["artifact:*.cef.fileHashSha256","artifact:*.id"])

    parameters = []

    # build parameters list for 'get_curated_associations' call
    for container_artifact_item in container_artifact_data:
        if container_artifact_item[0] is not None:
            parameters.append({
                "entity": container_artifact_item[0],
                "context": {'artifact_id': container_artifact_item[1]},
            })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.act("get curated associations", parameters=parameters, name="get_curated_associations", assets=["test-gti"], callback=parse_gti_enrichment)

    return


@phantom.playbook_block()
def parse_gti_enrichment(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("parse_gti_enrichment() called")

    ################################################################################
    # Extracts relevant curated intelligence fields from the GTI response.
    ################################################################################

    get_curated_associations_result_data = phantom.collect2(container=container, datapath=["get_curated_associations:action_result.data.*.data"], action_results=results)

    get_curated_associations_result_item_0 = [item[0] for item in get_curated_associations_result_data]

    parse_gti_enrichment__artifact_data = None

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...
    context = dict()
    data = get_curated_associations_result_item_0[0]
    
    def parse_relationship(relationship_name, want_name=False,  want_id=False, want_desc=False):
        """
        Helper to extract relationships
    
        Args:
            relationship_name (str): Name of the relationship
            want_desc (bool): Flag to include description
    
        Returns:
            list: List of relationships
        """
        items = []
        rel_list = data.get("relationships", {}).get(relationship_name, {}).get("data", [])
        for entry in rel_list:
            item = dict()
            attrs = entry.get("attributes", {}) or {}
    
            if want_id:
                item["id"] =  entry.get("id")
            if want_name:
                item["name"] = attrs.get("name")
            if want_desc and attrs.get("description"):
                item["description"] = attrs.get("description")
    
            if item:
                items.append(item)
    
        return items
    
    context["entity"] = data.get("id")
    context["entity_type"] = data.get("type")
    context["threat_severity_desc"] =data.get("attributes").get("threat_severity").get("level_description")
    context["threat_severity_level"] = data.get("attributes").get("threat_severity").get("threat_severity_level")
    context['campaigns'] = parse_relationship("campaigns",want_id=True)
    
    malware_families = parse_relationship("malware_families", want_id=True, want_name=True)
    context['malware_families_id'] = []
    context['malware_families_name'] = []
    for malware_family in malware_families:
        context['malware_families_id'].append(malware_family.get("id"))
        context['malware_families_name'].append(malware_family.get("name"))
    
    context['related_threat_actors'] = parse_relationship("related_threat_actors", want_id=True)
    context["reports"] = parse_relationship("reports")
    
    parse_gti_enrichment__artifact_data = {'cef': context}

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.save_block_result(key="parse_gti_enrichment__inputs:0:get_curated_associations:action_result.data.*.data", value=json.dumps(get_curated_associations_result_item_0))

    phantom.save_block_result(key="parse_gti_enrichment:artifact_data", value=json.dumps(parse_gti_enrichment__artifact_data))

    update_artifact(container=container)

    return


@phantom.playbook_block()
def update_artifact(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("update_artifact() called")

    ################################################################################
    # Updates the artifact with curated association context and enrichment details.
    ################################################################################

    container_artifact_data = phantom.collect2(container=container, datapath=["artifact:*.id","artifact:*.id"])
    parse_gti_enrichment__artifact_data = json.loads(_ if (_ := phantom.get_run_data(key="parse_gti_enrichment:artifact_data")) != "" else "null")  # pylint: disable=used-before-assignment

    parameters = []

    # build parameters list for 'update_artifact' call
    for container_artifact_item in container_artifact_data:
        parameters.append({
            "name": None,
            "tags": None,
            "label": None,
            "severity": None,
            "cef_field": None,
            "cef_value": None,
            "input_json": parse_gti_enrichment__artifact_data,
            "artifact_id": container_artifact_item[0],
            "cef_data_type": None,
            "overwrite_tags": None,
        })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.custom_function(custom_function="community/artifact_update", parameters=parameters, name="update_artifact")

    return


@phantom.playbook_block()
def on_finish(container, summary):
    phantom.debug("on_finish() called")

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    return