"""

"""


import phantom.rules as phantom
import json
from datetime import datetime, timedelta


@phantom.playbook_block()
def on_start(container):
    phantom.debug('on_start() called')

    # call 'update_dtm_alert_status_1' block
    update_dtm_alert_status_1(container=container)

    return

@phantom.playbook_block()
def update_dtm_alert_status_1(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("update_dtm_alert_status_1() called")

    # phantom.debug('Action: {0} {1}'.format(action['name'], ('SUCCEEDED' if success else 'FAILED')))

    source_data_identifier_value = container.get("source_data_identifier", None)

    parameters = []

    if source_data_identifier_value is not None:
        parameters.append({
            "id": source_data_identifier_value,
            "status": "Closed",
        })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.act("update dtm alert status", parameters=parameters, name="update_dtm_alert_status_1", assets=["dtm"])

    return


@phantom.playbook_block()
def on_finish(container, summary):
    phantom.debug("on_finish() called")

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    return