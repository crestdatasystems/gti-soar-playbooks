"""
This automation playbook extracts email addresses and domains from artifacts and orchestrates GTI-based domain enrichment to drive response actions.
"""


import phantom.rules as phantom
import json
from datetime import datetime, timedelta


@phantom.playbook_block()
def on_start(container):
    phantom.debug('on_start() called')

    # call 'extract_emails' block
    extract_emails(container=container)

    return

@phantom.playbook_block()
def extract_emails(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("extract_emails() called")

    ################################################################################
    # Extracts email addresses from the phishing artifact fields.
    ################################################################################

    container_artifact_data = phantom.collect2(container=container, datapath=["artifact:*.cef.email_address"])

    container_artifact_cef_item_0 = [item[0] for item in container_artifact_data]

    extract_emails__emails = None
    extract_emails__domains = None

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...
    
    extract_emails__emails = []
    extract_emails__domains = []
    input_data = container_artifact_cef_item_0

    if not input_data:
        phantom.debug("No valid input data provided")
        	
    # Normalize input into a flat list of strings
    if isinstance(input_data, list):
        emails = []
        for item in input_data:
            if isinstance(item, str):
                emails.extend(item.split(","))
    elif isinstance(input_data, str):
        emails = input_data.split(",")
    else:
        phantom.debug("No valid input data provided")

    for raw_email in emails:
        email = raw_email.strip()

        # Basic validation
        if "@" not in email:
            continue

        local_part, _, domain = email.rpartition("@")

        if not local_part or not domain:
            continue
        extract_emails__domains.append(domain.lower())
        extract_emails__emails.append(email)


    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.save_block_result(key="extract_emails__inputs:0:artifact:*.cef.email_address", value=json.dumps(container_artifact_cef_item_0))

    phantom.save_block_result(key="extract_emails:emails", value=json.dumps(extract_emails__emails))
    phantom.save_block_result(key="extract_emails:domains", value=json.dumps(extract_emails__domains))

    playbook_phishing_domain_enrichment___google_threat_intelligence_1(container=container)

    return


@phantom.playbook_block()
def playbook_phishing_domain_enrichment___google_threat_intelligence_1(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("playbook_phishing_domain_enrichment___google_threat_intelligence_1() called")

    extract_emails__emails = json.loads(_ if (_ := phantom.get_run_data(key="extract_emails:emails")) != "" else "null")  # pylint: disable=used-before-assignment
    extract_emails__domains = json.loads(_ if (_ := phantom.get_run_data(key="extract_emails:domains")) != "" else "null")  # pylint: disable=used-before-assignment

    inputs = {
        "email": extract_emails__emails,
        "domain": extract_emails__domains,
    }

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...
    for email, domain in zip(inputs['email'],inputs['domain']):
        inputs = {"email": email, "domain": domain}
        playbook_run_id = phantom.playbook("local/Phishing Domain Enrichment – Google Threat Intelligence", container=container, inputs=inputs)
        phantom.debug(f"playbook_run_id : {playbook_run_id}")
    ################################################################################
    ## Custom Code End
    ################################################################################

    # call playbook "local/Phishing Domain Enrichment – Google Threat Intelligence", returns the playbook_run_id
    #playbook_run_id = phantom.playbook("local/Phishing Domain Enrichment – Google Threat Intelligence", container=container, inputs=inputs)

    return

@phantom.playbook_block()
def on_finish(container, summary):
    phantom.debug("on_finish() called")

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    return